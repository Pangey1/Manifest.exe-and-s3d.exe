░██████╗██████╗░██████╗░
██╔════╝╚════██╗██╔══██╗
╚█████╗░░█████╔╝██║░░██║
░╚═══██╗░╚═══██╗██║░░██║
██████╔╝██████╔╝██████╔╝
╚═════╝░╚═════╝░╚═════╝░
This is a my new malware in C++non-safety file destroy you pc!
The developer bears no responsibility for damage caused by their Trojan.
Good luck!
: >